package com.oneui.fontviewer.service;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.oneui.fontviewer.ui.navigation.drawerlist.DrawerListItem;

import java.util.concurrent.atomic.AtomicBoolean;

public class BatchOperationState {

    private static final String TAG = "BatchOperationState";

    private static final MutableLiveData<Boolean> _isProcessing =
            new MutableLiveData<>(false);

    private static volatile DrawerListItem _sourceDrawerListItem = null;

    public static class ProgressData {
        public final int    current;
        public final int    total;
        public final String title;
        public final int    operationCode; 

        public ProgressData(int current, int total, String title) {
            this(current, total, title, 1);
        }

        public ProgressData(int current, int total, String title, int operationCode) {
            this.current = current;
            this.total   = total;
            this.title   = title;
            this.operationCode = operationCode;
        }
    }

    private static final MutableLiveData<ProgressData> _progress =
            new MutableLiveData<>();
    
    private static volatile AtomicBoolean _currentCancelFlag = null;

    private static volatile boolean _shouldReopenDialog = false;

    public static void setShouldReopenDialog(boolean shouldReopen) {
        _shouldReopenDialog = shouldReopen;
    }

    public static boolean consumeShouldReopenDialog() {
        boolean value = _shouldReopenDialog;
        _shouldReopenDialog = false;
        return value;
    }


    public static LiveData<Boolean> getIsProcessing() {
        return _isProcessing;
    }

    public static LiveData<ProgressData> getProgress() {
        return _progress;
    }

    public static DrawerListItem getSourceDrawerListItem() {
        return _sourceDrawerListItem;
    }
    
    @Deprecated
    public static int getSourceFragmentIndex() {
        if (_sourceDrawerListItem == null) return -1;
        switch (_sourceDrawerListItem) {
            case LOCAL_FONTS:  return 2;
            case SYSTEM_FONTS: return 3;
            case FAVORITES:    return 4;
            case TRASH:        return 5;
            default:           return -1;
        }
    }

    public static void setProcessing(boolean isProcessing) {
        if (!isProcessing) {
            _sourceDrawerListItem = null;
        }
        _isProcessing.postValue(isProcessing);
    }

    @Deprecated
    public static void setProcessing(boolean isProcessing, int sourceFragmentIndex) {
        if (isProcessing) {
            setSourceFragmentIndex(sourceFragmentIndex);
        } else {
            _sourceDrawerListItem = null;
        }
        _isProcessing.postValue(isProcessing);
        Log.d(TAG, "setProcessing=" + isProcessing + " | sourceDrawerListItem=" + _sourceDrawerListItem);
    }

    public static void setSourceDrawerListItem(DrawerListItem drawerListItem) {
        _sourceDrawerListItem = drawerListItem;
        Log.d(TAG, "setSourceDrawerListItem=" + drawerListItem);
    }

    @Deprecated
    public static void setSourceFragmentIndex(int index) {
        switch (index) {
            case 2:  _sourceDrawerListItem = DrawerListItem.LOCAL_FONTS;  break;
            case 3:  _sourceDrawerListItem = DrawerListItem.SYSTEM_FONTS; break;
            case 4:  _sourceDrawerListItem = DrawerListItem.FAVORITES;    break;
            case 5:  _sourceDrawerListItem = DrawerListItem.TRASH;        break;
            default: _sourceDrawerListItem = null;                   break;
        }
        Log.d(TAG, "setSourceFragmentIndex=" + index + " → _sourceDrawerListItem=" + _sourceDrawerListItem);
    }

    public static void updateProgress(int current, int total, String title) {
        _progress.postValue(new ProgressData(current, total, title, 1));
    }

    public static void updateProgress(int current, int total, String title, int operationCode) {
        _progress.postValue(new ProgressData(current, total, title, operationCode));
    }


    public static void setCancelFlag(AtomicBoolean flag) {
        _currentCancelFlag = flag;
        Log.d(TAG, "Cancel flag registered for current operation");
    }

    public static void requestCancel() {
        if (_currentCancelFlag != null) {
            _currentCancelFlag.set(true);
            Log.d(TAG, "Cancel requested via notification — flag set to true");
        } else {
            Log.w(TAG, "requestCancel() called but no cancel flag is registered");
        }
    }
}
