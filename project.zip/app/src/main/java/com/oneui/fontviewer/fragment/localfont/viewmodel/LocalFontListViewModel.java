package com.oneui.fontviewer.fragment.localfont.viewmodel;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.Transformations;

import com.oneui.fontviewer.data.entity.FontEntity;
import com.oneui.fontviewer.R;
import com.oneui.fontviewer.fragment.localfont.data.LocalFontCache;
import com.oneui.fontviewer.fragment.localfont.data.LocalFontRepository;
import com.oneui.fontviewer.fragment.trash.data.TrashRepository;   
import com.oneui.fontviewer.dialog.TrashActionDialogs;          
import com.oneui.fontviewer.fragment.localfont.manager.LocalFontPreferenceManager;
import com.oneui.fontviewer.utils.notification.BatchOperationState;
import com.oneui.fontviewer.utils.notification.OperationForegroundService;                  

public class LocalFontListViewModel extends AndroidViewModel {
    
    private static final String TAG = "LocalFontListViewModel";

    private static final long MIN_DIALOG_DURATION_MS = 2500;
    
    private final LocalFontRepository repository;
    private final TrashRepository     trashRepository; 
    private final LocalFontPreferenceManager preferenceManager;
    private final MutableLiveData<Boolean> isLoadingLiveData;
    private final MutableLiveData<String>  errorMessageLiveData;
    private final MutableLiveData<List<FontEntity>> fontsLiveData;

    private final MutableLiveData<List<FontEntity>> favoritesLiveData;

    private boolean mIsFolderSyncing = false;
    private List<FontEntity> mPendingSyncFonts = null;

    private AtomicBoolean trashCancelFlag = new AtomicBoolean(false);

    // خيط خلفي مخصص لتحميل معاينات الخطوط قبل نشر القائمة للواجهة
    private final ExecutorService fontPreloadExecutor = Executors.newSingleThreadExecutor();

    // نحتفظ بمرجع الـ LiveData الأصلية ومرجع الـ Observer لكل منهما
    // حتى نقدر نفك ربطهما صح في onCleared() ونمنعهما من الاستمرار بالعمل بعد موت الـ ViewModel
    private final LiveData<List<FontEntity>> mLocalFontsSource;
    private final LiveData<List<FontEntity>> mFavoriteFontsSource;
    private final Observer<List<FontEntity>> mLocalFontsObserver;
    private final Observer<List<FontEntity>> mFavoriteFontsObserver;
    

    public static class FontFileInfoWithMetadata {
        private final String name;
        private final String path;
        private final long size;
        private final long lastModified;
        private final String realName;
        private final String weightWidthLabel;
        private final boolean isFavorite;
        
        public FontFileInfoWithMetadata(FontEntity entity) {
            this.name             = entity.getFileName();
            this.path             = entity.getPath();
            this.size             = entity.getSize();
            this.lastModified     = entity.getLastModified();
            this.realName         = entity.getRealName();
            this.weightWidthLabel = entity.getWeightWidthLabel(); 
            this.isFavorite       = entity.isFavorite();          
        }
        
        
        
        public String  getName()             { return name; }
        public String  getPath()             { return path; }
        public long    getSize()             { return size; }
        public long    getLastModified()     { return lastModified; }
        public String  getRealName()         { return realName; }
        public String  getWeightWidthLabel() { return weightWidthLabel; }
        public boolean isFavorite()          { return isFavorite; }
        
        
    }
    
    public LocalFontListViewModel(@NonNull Application application) {
        super(application);
        
        repository      = LocalFontRepository.getInstance(application);
        trashRepository = TrashRepository.getInstance(application); 
        preferenceManager = new LocalFontPreferenceManager(application);
        isLoadingLiveData    = new MutableLiveData<>(false);
        errorMessageLiveData = new MutableLiveData<>();
        
        fontsLiveData = new MutableLiveData<>();

        favoritesLiveData = new MutableLiveData<>(new ArrayList<>());
        
        mLocalFontsSource = repository.getLocalFonts();
        mLocalFontsObserver = entities -> {
            if (entities != null) {
                if (mIsFolderSyncing) {
                    mPendingSyncFonts = entities;
                } else {
                    publishFontsAfterPreload(entities, null);
                }
            }
        };
        mLocalFontsSource.observeForever(mLocalFontsObserver);

        mFavoriteFontsSource = repository.getFavoriteFonts();
        mFavoriteFontsObserver = entities -> {
            if (entities != null) {
                favoritesLiveData.postValue(entities);
            }
        };
        mFavoriteFontsSource.observeForever(mFavoriteFontsObserver);
    }

    /**
     * يحمّل معاينات الخطوط لكل عناصر القائمة داخل LocalFontCache على خيط
     * خلفي، ثم يُرسل القائمة لواجهة المستخدم فقط بعد اكتمال التحميل.
     */
    private void publishFontsAfterPreload(List<FontEntity> entities, @Nullable Runnable onPublished) {
        if (fontPreloadExecutor.isShutdown()) {
            // الـ ViewModel اتقفلت (onCleared) بالفعل — منحاولش ننفذ حاجة على Executor مقفول
            Log.w(TAG, "publishFontsAfterPreload: executor is shut down, skipping");
            return;
        }
        try {
            fontPreloadExecutor.execute(() -> {
                List<String> paths = new ArrayList<>();
                for (FontEntity entity : entities) {
                    paths.add(entity.getPath());
                }
                LocalFontCache.getInstance().preloadFontsBlocking(paths);
                fontsLiveData.postValue(entities);
                if (onPublished != null) {
                    onPublished.run();
                }
            });
        } catch (RejectedExecutionException e) {
            Log.w(TAG, "publishFontsAfterPreload: task rejected, executor already shut down", e);
        }
    }

    public LiveData<List<FontFileInfoWithMetadata>> getFontsLiveData() {
        return Transformations.map(fontsLiveData, entities -> {
            if (entities == null) {
                return new ArrayList<>();
            }
            
            List<FontFileInfoWithMetadata> result = new ArrayList<>();
            for (FontEntity entity : entities) {
                result.add(new FontFileInfoWithMetadata(entity));
            }
            return result;
        });
    }


    public LiveData<List<FontFileInfoWithMetadata>> getFavoritesLiveData() {
        return Transformations.map(favoritesLiveData, entities -> {
            if (entities == null) {
                return new ArrayList<>();
            }

            List<FontFileInfoWithMetadata> result = new ArrayList<>();
            for (FontEntity entity : entities) {
                result.add(new FontFileInfoWithMetadata(entity));
            }
            return result;
        });
    }

    public void toggleFavoritesBatch(List<String> paths, boolean isFavorite, Runnable onSuccess) {
        if (paths == null || paths.isEmpty()) return;

        BatchOperationState.setProcessing(true);

        repository.updateFavoriteStatusBatch(paths, isFavorite, success -> {
            if (success) {
                Log.d(TAG, "★ Batch favorite toggled: " + paths.size() + " fonts → " + isFavorite);
                if (onSuccess != null) {
                    new Handler(Looper.getMainLooper()).post(() -> {
                        onSuccess.run();
                        BatchOperationState.setProcessing(false);
                    });
                } else {
                    BatchOperationState.setProcessing(false);
                }
            } else {
                Log.w(TAG, "Failed to batch toggle favorites");
                BatchOperationState.setProcessing(false);
            }
        });
    }

    public boolean renameFontInMemory(String oldPath, String newFileName) {
        File oldFile = new File(oldPath);
        
        if (!oldFile.exists()) {
            errorMessageLiveData.postValue("الملف غير موجود");
            return false;
        }
        
        File parentDir = oldFile.getParentFile();
        if (parentDir == null) {
            errorMessageLiveData.postValue("خطأ في المسار");
            return false;
        }
        
        File newFile = new File(parentDir, newFileName);
        
        if (newFile.exists()) {
            errorMessageLiveData.postValue("الاسم موجود بالفعل");
            return false;
        }
        
        if (!oldFile.renameTo(newFile)) {
            errorMessageLiveData.postValue("فشلت إعادة التسمية");
            return false;
        }
        
        List<FontEntity> currentList = fontsLiveData.getValue();
        if (currentList != null) {
            List<FontEntity> updatedList = new ArrayList<>(currentList);
            
            for (int i = 0; i < updatedList.size(); i++) {
                FontEntity entity = updatedList.get(i);
                if (entity.getPath().equals(oldPath)) {
                    FontEntity updatedEntity = new FontEntity(
                        newFile.getAbsolutePath(),
                        newFileName
                    );
                    updatedEntity.setSize(entity.getSize());
                    updatedEntity.setLastModified(newFile.lastModified());
                    updatedEntity.setRealName(entity.getRealName());
                    updatedEntity.setAccessCount(entity.getAccessCount());
                    updatedEntity.setLastAccessTime(entity.getLastAccessTime());
                    updatedEntity.setWeightWidthLabel(entity.getWeightWidthLabel());
                    updatedEntity.setFavorite(entity.isFavorite());
                    
                    updatedList.set(i, updatedEntity);
                    break;
                }
            }
            
            fontsLiveData.postValue(updatedList);
        }

        List<FontEntity> currentFavorites = favoritesLiveData.getValue();
        if (currentFavorites != null) {
            List<FontEntity> updatedFavorites = new ArrayList<>(currentFavorites);

            for (int i = 0; i < updatedFavorites.size(); i++) {
                FontEntity entity = updatedFavorites.get(i);
                if (entity.getPath().equals(oldPath)) {
                    FontEntity updatedEntity = new FontEntity(
                        newFile.getAbsolutePath(),
                        newFileName
                    );
                    updatedEntity.setSize(entity.getSize());
                    updatedEntity.setLastModified(newFile.lastModified());
                    updatedEntity.setRealName(entity.getRealName());
                    updatedEntity.setAccessCount(entity.getAccessCount());
                    updatedEntity.setLastAccessTime(entity.getLastAccessTime());
                    updatedEntity.setWeightWidthLabel(entity.getWeightWidthLabel());
                    updatedEntity.setFavorite(true); 
                    
                    updatedFavorites.set(i, updatedEntity);
                    break;
                }
            }

            favoritesLiveData.postValue(updatedFavorites);
        }
        
        repository.updatePath(oldPath, newFile.getAbsolutePath(), newFileName);
        
        Log.d(TAG, "Font renamed in memory: " + oldPath + " -> " + newFile.getAbsolutePath());
        
        return true;
    }


    public void moveFontsToTrashInMemory(@NonNull List<String> paths,
                                          TrashRepository.OnProgressListener progressListener,
                                          Runnable onComplete) {
        if (paths.isEmpty()) return;

        List<FontEntity> currentList = fontsLiveData.getValue();
        if (currentList == null || currentList.isEmpty()) {
            Log.w(TAG, "moveFontsToTrashInMemory: font list is empty");
            if (onComplete != null) new Handler(Looper.getMainLooper()).post(onComplete);
            return;
        }

        List<FontEntity> fontsToMove = new ArrayList<>();
        for (FontEntity entity : currentList) {
            if (paths.contains(entity.getPath())) {
                fontsToMove.add(entity);
            }
        }

        if (fontsToMove.isEmpty()) {
            Log.w(TAG, "moveFontsToTrashInMemory: no matching entities found for given paths");
            if (onComplete != null) new Handler(Looper.getMainLooper()).post(onComplete);
            return;
        }

        int sourceIndex = BatchOperationState.getSourceFragmentIndex();
        if (sourceIndex == -1) sourceIndex = 2; 
        BatchOperationState.setProcessing(true, sourceIndex);

        trashCancelFlag = new AtomicBoolean(false);
        BatchOperationState.setCancelFlag(trashCancelFlag);

        final long startTime = System.currentTimeMillis();

        String movingTitle = getApplication().getResources()
                .getQuantityString(R.plurals.progress_moving_to_trash, fontsToMove.size());
        android.content.Intent moveServiceIntent = new android.content.Intent(
                getApplication(), OperationForegroundService.class);
        moveServiceIntent.putExtra(OperationForegroundService.EXTRA_NOTIF_ID,
                TrashActionDialogs.NOTIF_ID_MOVE);
        moveServiceIntent.putExtra(OperationForegroundService.EXTRA_TITLE, movingTitle);
        moveServiceIntent.putExtra(OperationForegroundService.EXTRA_TOTAL, fontsToMove.size());
        moveServiceIntent.putExtra(OperationForegroundService.EXTRA_SOURCE_FRAGMENT, sourceIndex);
        ContextCompat.startForegroundService(getApplication(), moveServiceIntent);
 
        trashRepository.moveToTrashBatch(
                getApplication(),
                fontsToMove,
                trashCancelFlag,

                (current, total) -> {
                    TrashActionDialogs.updateMoveToTrashNotification(getApplication(), current, total);

                    String progressTitle = getApplication().getResources()
                            .getQuantityString(
                                    R.plurals.progress_moving_to_trash, total);
                    BatchOperationState.updateProgress(current, total, progressTitle);

                    if (progressListener != null) {
                        try {
                            progressListener.onProgress(current, total);
                        } catch (Exception e) {
                            Log.w(TAG, "progressListener.onProgress() failed"
                                    + " (fragment may be detached): " + e.getMessage());
                        }
                    }
                },

                (succeeded, failed) -> {
                    Log.d(TAG, "moveFontsToTrashInMemory done"
                            + " — succeeded: " + succeeded
                            + ", failed: " + failed
                            + ", cancelled: " + trashCancelFlag.get());


                    long elapsedTime = System.currentTimeMillis() - startTime;
                    long delay = Math.max(0, MIN_DIALOG_DURATION_MS - elapsedTime);

                    if (onComplete != null) {
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            getApplication().stopService(new android.content.Intent(
                                    getApplication(), OperationForegroundService.class));
                            TrashActionDialogs.dismissMoveToTrashNotification(getApplication());

                            onComplete.run(); 
                            BatchOperationState.setProcessing(false);
                        }, delay);
                    } else {
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            getApplication().stopService(new android.content.Intent(
                                    getApplication(), OperationForegroundService.class));
                            TrashActionDialogs.dismissMoveToTrashNotification(getApplication());
                            BatchOperationState.setProcessing(false);
                        }, delay);
                    }
                }
        );
    }

    public void cancelTrashOperation() {
        if (trashCancelFlag != null) {
            trashCancelFlag.set(true);
            Log.d(TAG, "cancelTrashOperation: cancellation requested");
        }
    } 
    
    public LiveData<Boolean> getIsLoadingLiveData() {
        return isLoadingLiveData;
    }
    
    public void loadFonts() {
        String folderPath = preferenceManager.getFontFolderPath();
        if (folderPath == null) {
            Log.w(TAG, "No folder path saved");
            return;
        }
        
        loadFontsFromPath(folderPath, false);
    }
    
    public void loadFontsFromPath(String folderPath) {
        loadFontsFromPath(folderPath, true);
    }

    public void loadFontsFromPath(String folderPath, boolean showLoading) {
        if (folderPath == null || folderPath.isEmpty()) {
            return;
        }

        if (Boolean.TRUE.equals(BatchOperationState.getIsProcessing().getValue())) {
            Log.w(TAG, "Skipping load and sync: A batch operation is currently running.");
            return;
        }

        if (showLoading) {
            isLoadingLiveData.postValue(true);
        }

        mIsFolderSyncing = true;

        final long startTime = System.currentTimeMillis();
        
        repository.loadAndSyncLocalFonts(folderPath, new LocalFontRepository.OnSyncCompleteListener() {
            @Override
            public void onSyncComplete(int added, int updated, int deleted) {
                String message = String.format("Synced: %d added, %d updated, %d deleted",
                    added, updated, deleted);
                Log.d(TAG, message);
            }

            @Override
            public void onFullExtractionComplete() {
                long elapsedTime = System.currentTimeMillis() - startTime;
                long delay = showLoading ? Math.max(0, 2500 - elapsedTime) : 0;

                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                    mIsFolderSyncing = false;

                    List<FontEntity> toPublish;
                    if (mPendingSyncFonts != null) {
                        toPublish = mPendingSyncFonts;
                        mPendingSyncFonts = null;
                    } else {
                        List<FontEntity> currentFonts = fontsLiveData.getValue();
                        toPublish = currentFonts != null ? currentFonts : new ArrayList<>();
                    }

                    publishFontsAfterPreload(toPublish, () -> {
                        if (showLoading) {
                            isLoadingLiveData.postValue(false);
                        }
                    });
                }, delay);
            }
        });
    }
    
    public void recordFontAccess(String fontPath) {
        if (fontPath != null && !fontPath.isEmpty()) {
            repository.recordAccess(fontPath);
        }
    }
    
    
    
    public void saveFolderPath(String folderPath) {
        if (folderPath != null && !folderPath.isEmpty()) {
            preferenceManager.saveFontFolderPath(folderPath);
        }
    }
    
    public String getSavedFolderPath() {
        return preferenceManager.getFontFolderPath();
    }
    
    public boolean hasSavedFolder() {
        return preferenceManager.hasFontFolderPath();
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        // لازم نلغي تسجيل الـ Observers قبل قفل الـ Executor
        // عشان أي تحديث متأخر من قاعدة البيانات ميحاولش يستخدم Executor مقفول
        mLocalFontsSource.removeObserver(mLocalFontsObserver);
        mFavoriteFontsSource.removeObserver(mFavoriteFontsObserver);
        fontPreloadExecutor.shutdownNow();
    }
    
    
                    }
