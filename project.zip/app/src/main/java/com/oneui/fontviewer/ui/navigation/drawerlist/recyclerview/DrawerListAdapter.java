package com.oneui.fontviewer.ui.navigation.drawerlist.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import com.oneui.fontviewer.R;
import com.oneui.fontviewer.ui.navigation.drawerlist.DrawerListItem;

public class DrawerListAdapter extends RecyclerView.Adapter<DrawerListViewHolder> {

    private static final int VIEW_TYPE_SEPARATOR = 0;
    private static final int VIEW_TYPE_ITEM      = 1;

    private final Context mContext;

    private final List<DrawerListItem> mDrawerListItems;

    private final DrawerListener mListener;

    private DrawerListItem mSelectedDrawerListItem = DrawerListItem.FONT_VIEWER;


    public interface DrawerListener {
        boolean onDrawerItemSelected(DrawerListItem drawerListItem);
    }


    public DrawerListAdapter(
            @NonNull Context context, List<DrawerListItem> drawerListItems, DrawerListener listener) {
        mContext    = context;
        mDrawerListItems = drawerListItems;
        mListener   = listener;
    }


    @Override
    public int getItemCount() {
        return mDrawerListItems.size();
    }

    @Override
    public int getItemViewType(int position) {
        return (mDrawerListItems.get(position) == null) ? VIEW_TYPE_SEPARATOR : VIEW_TYPE_ITEM;
    }

    @NonNull
    @Override
    public DrawerListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);

        boolean isSeparator = (viewType == VIEW_TYPE_SEPARATOR);
        int layoutRes = isSeparator ? R.layout.drawer_list_separator
                                    : R.layout.drawer_list_item;
        View view = inflater.inflate(layoutRes, parent, false);
        return new DrawerListViewHolder(view, isSeparator);
    }

    @Override
    public void onBindViewHolder(@NonNull DrawerListViewHolder holder, int position) {
        if (holder.isSeparator()) return;

        DrawerListItem drawerListItem = mDrawerListItems.get(position);
        if (drawerListItem == null) return;

        boolean isSelected = (drawerListItem == mSelectedDrawerListItem);

        int iconRes = getIconForDrawerListItem(drawerListItem, isSelected);
        String title = getTitleForDrawerListItem(drawerListItem);

        if (iconRes != 0)     holder.setIcon(iconRes);
        if (!title.isEmpty()) holder.setTitle(title);

        holder.setSelected(isSelected);

        holder.itemView.setOnClickListener(v -> {
            final int adapterPos = holder.getBindingAdapterPosition();
            if (adapterPos == RecyclerView.NO_POSITION) return;

            DrawerListItem clickedDrawerListItem = mDrawerListItems.get(adapterPos);
            if (clickedDrawerListItem == null) return;

            boolean selectionChanged = false;
            if (mListener != null) {
                selectionChanged = mListener.onDrawerItemSelected(clickedDrawerListItem);
            }

            if (selectionChanged) {
                setSelectedItem(clickedDrawerListItem);
            }
        });
    }


    private int getIconForDrawerListItem(DrawerListItem drawerListItem, boolean selected) {
        switch (drawerListItem) {
            case HOME:
                return dev.oneuiproject.oneui.R.drawable.ic_oui_home_outline;
            case FONT_VIEWER:
                return R.drawable.ic_oui_text_style_default;
            case LOCAL_FONTS:
                return selected
                        ? dev.oneuiproject.oneui.R.drawable.ic_oui_device
                        : dev.oneuiproject.oneui.R.drawable.ic_oui_device_outline;
            case SYSTEM_FONTS:
                return selected
                        ? R.drawable.ic_android
                        : R.drawable.ic_android_outline;
            case FAVORITES:
                return selected
                        ? dev.oneuiproject.oneui.R.drawable.ic_oui_favorite_on
                        : dev.oneuiproject.oneui.R.drawable.ic_oui_favorite_off;
            case TRASH:
                return selected
                        ? dev.oneuiproject.oneui.R.drawable.ic_oui_delete
                        : dev.oneuiproject.oneui.R.drawable.ic_oui_delete_outline;
            default:
                return 0;
        }
    }

    private String getTitleForDrawerListItem(DrawerListItem drawerListItem) {
        switch (drawerListItem) {
            case HOME:
                return mContext.getString(R.string.drawer_home);
            case FONT_VIEWER:
                return mContext.getString(R.string.drawer_font_viewer);
            case LOCAL_FONTS:
                return mContext.getString(R.string.drawer_local_fonts);
            case SYSTEM_FONTS:
                return mContext.getString(R.string.drawer_system_fonts);
            case FAVORITES:
                return mContext.getString(R.string.drawer_favorites);
            case TRASH:
                return mContext.getString(R.string.drawer_trash);
            default:
                return "";
        }
    }


    public void setSelectedItem(DrawerListItem drawerListItem) {
        if (drawerListItem == null || drawerListItem == mSelectedDrawerListItem) return;

        DrawerListItem prev = mSelectedDrawerListItem;
        mSelectedDrawerListItem = drawerListItem;

        int prevPos = indexOfDrawerListItem(prev);
        int newPos  = indexOfDrawerListItem(drawerListItem);

        if (prevPos >= 0) notifyItemChanged(prevPos);
        if (newPos  >= 0) notifyItemChanged(newPos);
    }

    private int indexOfDrawerListItem(DrawerListItem drawerListItem) {
        if (drawerListItem == null) return -1;
        for (int i = 0; i < mDrawerListItems.size(); i++) {
            if (mDrawerListItems.get(i) == drawerListItem) return i;
        }
        return -1;
    }

    
}
