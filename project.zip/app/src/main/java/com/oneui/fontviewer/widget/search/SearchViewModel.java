package com.oneui.fontviewer.widget.search;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SearchViewModel extends ViewModel {
    
    private final MutableLiveData<String> searchQueryLiveData = new MutableLiveData<>("");
    private final MutableLiveData<Boolean> isSearchActiveLiveData = new MutableLiveData<>(false);
    
    public LiveData<String> getSearchQueryLiveData() {
        return searchQueryLiveData;
    }
    
    public LiveData<Boolean> getIsSearchActiveLiveData() {
        return isSearchActiveLiveData;
    }
    
    public void setSearchQuery(String query) {
        String newQuery = query == null ? "" : query;
        searchQueryLiveData.setValue(newQuery);
    }  
    
    public void activateSearch() {
        isSearchActiveLiveData.setValue(true);
    }
    
    public void deactivateSearch() {
        isSearchActiveLiveData.setValue(false);
        searchQueryLiveData.setValue("");
    }
    
    public boolean isSearchActive() {
        Boolean active = isSearchActiveLiveData.getValue();
        return active != null && active;
    }
}
