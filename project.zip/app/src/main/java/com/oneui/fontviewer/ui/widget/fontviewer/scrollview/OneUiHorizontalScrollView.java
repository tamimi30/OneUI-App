package com.oneui.fontviewer.ui.widget.fontviewer.scrollview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.HorizontalScrollView;

public class OneUiHorizontalScrollView extends HorizontalScrollView {

    public OneUiHorizontalScrollView(Context context) {
        super(context);
    }

    public OneUiHorizontalScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public OneUiHorizontalScrollView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void requestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        // نتجاهل طلب الـ Spinner بمنعنا من الاعتراض،
        // حتى نبقى قادرين على اكتشاف السكرول البطيء وسرقته منه.
    }
}
